#include "dictionary.h"
#include <fstream>
#include <iostream>
#include <assert.h>

int getline()
{
  system("wc -l database.txt > temp.txt");
  std::ifstream infile;
  infile.open("temp.txt");
  int line;
  infile>>line;
  infile.close();
  return line;
}


void assign_data(Dictionary& data,int flag)
{
  int line=getline();
  if(flag==1)
    {
      data.assign(1,2*line);
    }
  else if(flag==2)
    {
     
      data.assign(2,2*line);
    }
  else
    {
      int m,m_re;
      std::cout<<"Enter Size of Table(Prime number) greater than "<<2*getline()<<"\n";
      std::cin>>m;
      std::cout<<"Enter a prime num for double hash\n";
      std::cin>>m_re;
      data.assign(3,m,m_re);
    }
 
}
int main()
{
  int line=getline();
  std::cout<<"Enter Collision Method:\nEnter:\n1 for Chaining\n2 for Linear Probing\n3 for double hashing\n ";
  int flag;
  std::cin>>flag;
  int m=11;
  int m_re=5;
  Dictionary data;
  if(flag==1)
    {
      data.assign(1,2*line);
    }
  else if(flag==2)
    {
     
      data.assign(2,2*line);
    }
  else
    {
      std::cout<<"Enter Size of Table(Prime number) greater than "<<2*line<<"\n";
      std::cin>>m;
      std::cout<<"Enter a prime num for double hash\n";
      std::cin>>m_re;
      if(!data.assign(3,m,m_re))
	{
	  assign_data(data,flag);
	}
    }
  
  //assign_data(data,flag,m,m_re);
  int ch=0;
  record a;
  char key[10];
  while(ch!=5)
    {
      std::cout<<"Menu::\n1 for insertion\n2 for search\n3 for delete\n4 for print\n5 for exit\n";
      std::cin>>ch;
      switch(ch){
      case 1:
	std::cout<<"Input record:\nItem_Num Item_Name Remaining_Num Price Manufacturing_Company Manufacturing_addres\n";
	a.input();
	if(!data.insert(a))
	  {
      	    assign_data(data,flag);
	  }
	else
	data.modifyFile();
	break;
      case 2:
	std::cout<<"Enter Key\n";
	std::cin>>key;
	if(data.search(key))
	  std::cout<<"Found!!\n";
	else
	  std::cout<<"Not Found!!\n";
	break;
      case 3:
	std::cout<<"Enter Key\n";
	std::cin>>key;
	if(data.delete1(key))
	  std::cout<<"Deleted Successfully!!\n";
	else
	  std::cout<<"Not Found!!\n";
	break;
      case 4:
	std::cout<<"Enter Key\n";
	std::cin>>key;
	if(!data.print(key))
	  std::cout<<"Not Found!!\n";
	break;
      }
    }

  return 0;
}
