#include<iostream>
#include"hospital-patient.h"
#include"linked_lists.h"
#include"Linear_lists.h"
#include"hash.h"

class Dictionary{
private:
  char collmethod;
  int m;
  openhash data1;
  chain_hash data2;
public:
  Dictionary(char );
  Assign();
  Insert();
  Delete();
  Search(char key[]);
  Display();
  Modify_table();
}

Dictionary::Dictionary(char coll,int size)
{
  collmethod=coll;
  m=size;
  if(coll=='l'||coll=='d')
  {
    openhash(coll,size);
  }
  else if(coll==c)
  {
    chain_hash(size);
  }
}



int main()
{
  char temp;
  cout<<"Enter the collision method: l for linear probing, d for double hashing, c for chain hashing\n";
  cin>>temp;
  int m=13;
  Dictionary(temp,m);
  return 0;
}
